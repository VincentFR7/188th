import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Send, User as UserIcon, Flag, Reply, Star, Shield } from 'lucide-react';

// Données de test pour simuler un forum
const forumData = {
  'announcements': {
    title: 'Annonces',
    description: 'Informations et annonces importantes concernant le 188th Regiment',
    posts: [
      {
        id: 1,
        author: {
          username: 'CommanderPrice',
          rank: 'Officier 188th',
          avatar: null,
          isAdmin: true
        },
        content: `Soldats du 188th Regiment,

Je vous informe de notre prochaine opération majeure qui aura lieu le 15 juin. Tous les membres sont attendus pour un briefing préliminaire le 10 juin à 20h sur notre serveur Discord.

L'opération "Marteau de Thor" sera notre plus grande mission à ce jour. Préparez votre équipement et révisez vos procédures opérationnelles standards.

Pour la gloire du 188th!`,
        date: '2025-05-28',
        time: '10:32',
        pinned: true
      },
      {
        id: 2,
        author: {
          username: 'MajorTom',
          rank: 'Sous-Officier 188th',
          avatar: null
        },
        content: `Présent Commandant. Je m'occuperai de briefer l'escouade Delta sur les protocoles de communication.`,
        date: '2025-05-28',
        time: '11:05'
      },
      {
        id: 3,
        author: {
          username: 'SoldatRyan',
          rank: 'Homme du rang 188th',
          avatar: null
        },
        content: `Je confirme ma présence pour le briefing et l'opération. L'escouade Charlie sera au complet.`,
        date: '2025-05-28',
        time: '14:27'
      }
    ]
  },
  'missions': {
    title: 'Missions',
    description: 'Discussions sur les missions passées et à venir',
    posts: [
      {
        id: 1,
        author: {
          username: 'Ranger_Lead',
          rank: 'Officier 188th',
          avatar: null
        },
        content: `Débriefing de la mission "Aigle Noir"

Excellente performance de toutes les escouades lors de cette opération. Points à améliorer:
- Coordination radio entre les équipes Alpha et Bravo
- Temps de réaction lors de l'embuscade du secteur Est
- Utilisation des fumigènes pour couvrir les évacuations

Mentions spéciales:
- SoldatRyan pour la neutralisation du nid de mitrailleuses
- Équipe Charlie pour la sécurisation de l'objectif secondaire en temps record`,
        date: '2025-05-25',
        time: '18:45'
      }
    ]
  }
};

const ForumPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [newMessage, setNewMessage] = useState('');
  
  if (!id || !forumData[id as keyof typeof forumData]) {
    return (
      <div className="p-8 text-center">
        <h2 className="text-xl font-bold mb-4">Forum non trouvé</h2>
        <p className="text-neutral-400">Le forum que vous recherchez n'existe pas ou vous n'avez pas les permissions nécessaires.</p>
      </div>
    );
  }
  
  const forum = forumData[id as keyof typeof forumData];
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      // Ici, vous ajouteriez la logique pour envoyer le message au serveur
      setNewMessage('');
    }
  };
  
  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{forum.title}</h1>
        <p className="text-neutral-400 mt-1">{forum.description}</p>
      </div>
      
      <div className="space-y-6">
        {forum.posts.map((post) => (
          <div key={post.id} className={`bg-neutral-800/20 border border-neutral-700 rounded-lg overflow-hidden ${post.pinned ? 'border-l-4 border-l-amber-600' : ''}`}>
            <div className="bg-neutral-800/50 px-4 py-2 border-b border-neutral-700 flex items-center justify-between">
              <div className="flex items-center">
                <div className="relative mr-3">
                  <div className="w-8 h-8 rounded-full bg-neutral-700 flex items-center justify-center overflow-hidden">
                    {post.author.avatar ? (
                      <img src={post.author.avatar} alt={post.author.username} className="w-full h-full object-cover" />
                    ) : (
                      <UserIcon size={16} className="text-neutral-300" />
                    )}
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center">
                    <span className="font-medium">{post.author.username}</span>
                    {post.author.isAdmin && (
                      <span className="ml-2 text-xs bg-red-900/30 text-red-400 px-2 py-0.5 rounded">
                        Admin
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-amber-500">{post.author.rank}</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                {post.pinned && (
                  <div className="text-amber-500 flex items-center">
                    <Flag size={14} className="mr-1" />
                    <span className="text-xs">Épinglé</span>
                  </div>
                )}
                <div className="text-neutral-400 text-xs">
                  {post.date} à {post.time}
                </div>
              </div>
            </div>
            
            <div className="p-4 whitespace-pre-line">
              {post.content}
            </div>
            
            <div className="bg-neutral-800/30 px-4 py-2 border-t border-neutral-700 flex items-center justify-between">
              <div className="flex space-x-2">
                <button className="flex items-center text-xs text-neutral-400 hover:text-white">
                  <Reply size={14} className="mr-1" />
                  <span>Répondre</span>
                </button>
                <button className="flex items-center text-xs text-neutral-400 hover:text-white">
                  <Star size={14} className="mr-1" />
                  <span>Ajouter aux favoris</span>
                </button>
              </div>
              
              <div className="flex space-x-2">
                {post.author.isAdmin && (
                  <button className="flex items-center text-xs text-neutral-400 hover:text-white">
                    <Shield size={14} className="mr-1" />
                    <span>Modération</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8">
        <h3 className="text-lg font-medium mb-3">Répondre</h3>
        <form onSubmit={handleSendMessage}>
          <div className="mb-3">
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              className="w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
              rows={4}
              placeholder="Écrivez votre message ici..."
            />
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="flex items-center bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded transition-colors"
            >
              <Send size={16} className="mr-2" />
              <span>Envoyer</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ForumPage;