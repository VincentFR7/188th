import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Users, Shield, PlusCircle, Flag, Info, Star } from 'lucide-react';

const categories = [
  {
    id: 'general',
    name: 'Général',
    description: 'Information générale et règlement du forum',
    channels: [
      { id: 'announcements', name: 'Annonces', icon: <Flag size={16} />, posts: 12, lastPost: { author: 'CommanderPrice', date: 'Hier' } },
      { id: 'welcome', name: 'Bienvenue', icon: <Users size={16} />, posts: 45, lastPost: { author: 'SoldatRyan', date: 'Il y a 3 heures' } },
      { id: 'rules', name: 'Règlement', icon: <Shield size={16} />, posts: 2, lastPost: { author: 'CommanderPrice', date: 'Il y a 1 semaine' } }
    ]
  },
  {
    id: 'regiment',
    name: '188th Regiment',
    description: 'Tout ce qui concerne les opérations, la stratégie et les entraînements du 188th Regiment',
    channels: [
      { id: 'missions', name: 'Missions', icon: <Star size={16} />, posts: 32, lastPost: { author: 'MajorTom', date: 'Il y a 5 heures' } },
      { id: 'training', name: 'Entraînement', icon: <Info size={16} />, posts: 18, lastPost: { author: 'Ranger_Lead', date: 'Il y a 2 jours' } },
      { id: 'operations', name: 'Opérations', icon: <MessageSquare size={16} />, posts: 78, lastPost: { author: 'CommanderPrice', date: 'Aujourd\'hui' } }
    ]
  }
];

const HomePage: React.FC = () => {
  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      <div className="bg-neutral-800/30 border border-neutral-700 rounded-lg p-4 mb-6">
        <div className="flex items-center space-x-2 mb-2">
          <Shield className="h-5 w-5 text-amber-500" />
          <h1 className="text-xl font-bold">188<sup>th</sup> Regiment - Forum Officiel</h1>
        </div>
        <p className="text-neutral-300">
          Bienvenue sur le forum officiel du 188<sup>th</sup> Regiment. Ce forum est réservé aux membres et aux soldats. 
          Merci de respecter la hiérarchie et le code de conduite militaire en vigueur.
        </p>
      </div>
      
      <div className="space-y-6">
        {categories.map(category => (
          <div key={category.id} className="bg-neutral-800/20 border border-neutral-700 rounded-lg overflow-hidden">
            <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-700">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-lg">{category.name}</h2>
                {category.id === 'regiment' && (
                  <div className="px-2 py-1 bg-amber-600/20 text-amber-500 text-xs font-semibold rounded">
                    Accès Restreint
                  </div>
                )}
              </div>
              <p className="text-sm text-neutral-400 mt-1">{category.description}</p>
            </div>
            
            <div className="divide-y divide-neutral-700/50">
              {category.channels.map(channel => (
                <div key={channel.id} className="hover:bg-neutral-800/30 transition-colors">
                  <Link to={`/forum/${channel.id}`} className="flex items-start p-4">
                    <div className="p-2 bg-neutral-800 rounded-lg mr-3">
                      {channel.icon}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center">
                        <h3 className="font-medium text-white">{channel.name}</h3>
                        <span className="ml-2 text-xs bg-neutral-800 text-neutral-400 px-2 py-0.5 rounded">
                          {channel.posts} messages
                        </span>
                      </div>
                      <p className="text-sm text-neutral-400 mt-0.5 truncate">
                        Dernier message par{' '}
                        <span className="text-amber-500">{channel.lastPost.author}</span> • {channel.lastPost.date}
                      </p>
                    </div>
                    
                    <div className="text-neutral-500 ml-4">
                      <MessageSquare size={18} />
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-neutral-800/20 border border-neutral-700 rounded-lg p-4">
          <h3 className="font-semibold text-amber-500 flex items-center gap-2 mb-3">
            <Users size={18} />
            <span>Statistiques</span>
          </h3>
          <div className="text-sm space-y-2 text-neutral-300">
            <div className="flex justify-between">
              <span>Total des membres:</span>
              <span className="font-medium">124</span>
            </div>
            <div className="flex justify-between">
              <span>Messages:</span>
              <span className="font-medium">2,357</span>
            </div>
            <div className="flex justify-between">
              <span>Dernier membre:</span>
              <span className="font-medium text-amber-500">SoldatRyan</span>
            </div>
          </div>
        </div>
        
        <div className="bg-neutral-800/20 border border-neutral-700 rounded-lg p-4">
          <h3 className="font-semibold text-amber-500 flex items-center gap-2 mb-3">
            <Shield size={18} />
            <span>Grades</span>
          </h3>
          <div className="text-sm space-y-2 text-neutral-300">
            <div className="flex justify-between items-center">
              <span>Officiers:</span>
              <span className="font-medium bg-amber-900/50 text-amber-500 px-2 py-0.5 rounded text-xs">8</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Sous-Officiers:</span>
              <span className="font-medium bg-amber-900/50 text-amber-500 px-2 py-0.5 rounded text-xs">22</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Hommes du rang:</span>
              <span className="font-medium bg-neutral-800 text-neutral-400 px-2 py-0.5 rounded text-xs">94</span>
            </div>
          </div>
        </div>
        
        <div className="bg-neutral-800/20 border border-neutral-700 rounded-lg p-4">
          <h3 className="font-semibold text-amber-500 flex items-center gap-2 mb-3">
            <Star size={18} />
            <span>Activité</span>
          </h3>
          <div className="text-sm space-y-2 text-neutral-300">
            <div className="flex justify-between">
              <span>Messages aujourd'hui:</span>
              <span className="font-medium">37</span>
            </div>
            <div className="flex justify-between">
              <span>Discussions actives:</span>
              <span className="font-medium">14</span>
            </div>
            <div className="flex justify-between">
              <span>Membres en ligne:</span>
              <span className="font-medium text-green-500">12</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;