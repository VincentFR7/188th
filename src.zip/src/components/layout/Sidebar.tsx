import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Users, Star, Shield, PlusCircle, Flag, Award } from 'lucide-react';

const categories = [
  {
    id: 'general',
    name: 'Général',
    channels: [
      { id: 'announcements', name: 'Annonces', icon: <Flag size={16} /> },
      { id: 'welcome', name: 'Bienvenue', icon: <Users size={16} /> },
      { id: 'rules', name: 'Règlement', icon: <Shield size={16} /> }
    ]
  },
  {
    id: 'regiment',
    name: '188th Regiment',
    channels: [
      { id: 'missions', name: 'Missions', icon: <Star size={16} /> },
      { id: 'training', name: 'Entraînement', icon: <Award size={16} /> },
      { id: 'operations', name: 'Opérations', icon: <MessageSquare size={16} /> }
    ]
  }
];

const Sidebar: React.FC = () => {
  return (
    <div className="py-4 h-full">
      <div className="px-4 mb-4">
        <h2 className="text-sm uppercase tracking-wider text-neutral-500 font-semibold mb-1">
          Espaces de discussion
        </h2>
      </div>
      
      <div className="space-y-4">
        {categories.map(category => (
          <div key={category.id} className="px-3">
            <div className="flex items-center justify-between px-2 mb-1">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                {category.name}
              </h3>
              <button className="text-neutral-500 hover:text-neutral-300 p-0.5">
                <PlusCircle size={14} />
              </button>
            </div>
            <div className="space-y-1">
              {category.channels.map(channel => (
                <Link
                  key={channel.id}
                  to={`/forum/${channel.id}`}
                  className="flex items-center p-2 text-sm text-neutral-400 hover:text-white hover:bg-neutral-700 rounded-md transition-colors group"
                >
                  <span className="mr-2 text-neutral-500 group-hover:text-neutral-300">
                    {channel.icon}
                  </span>
                  <span>{channel.name}</span>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      <div className="px-4 mt-6">
        <h2 className="text-sm uppercase tracking-wider text-neutral-500 font-semibold mb-2">
          Membres en ligne
        </h2>
        <div className="space-y-2">
          <div className="flex items-center p-2 hover:bg-neutral-700 rounded transition-colors cursor-pointer">
            <div className="relative">
              <div className="w-8 h-8 rounded-full bg-neutral-700 flex items-center justify-center overflow-hidden">
                <span className="text-xs font-semibold">RL</span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-green-500 border-2 border-neutral-800"></div>
            </div>
            <div className="ml-2 text-sm">
              <div className="font-medium">Ranger_Lead</div>
              <div className="text-xs text-amber-500">Officier 188th</div>
            </div>
          </div>
          
          <div className="flex items-center p-2 hover:bg-neutral-700 rounded transition-colors cursor-pointer">
            <div className="relative">
              <div className="w-8 h-8 rounded-full bg-neutral-700 flex items-center justify-center overflow-hidden">
                <span className="text-xs font-semibold">MJ</span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-green-500 border-2 border-neutral-800"></div>
            </div>
            <div className="ml-2 text-sm">
              <div className="font-medium">MajorTom</div>
              <div className="text-xs text-amber-500">Sous-Officier 188th</div>
            </div>
          </div>
          
          <div className="flex items-center p-2 hover:bg-neutral-700 rounded transition-colors cursor-pointer">
            <div className="relative">
              <div className="w-8 h-8 rounded-full bg-neutral-700 flex items-center justify-center overflow-hidden">
                <span className="text-xs font-semibold">SR</span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-green-500 border-2 border-neutral-800"></div>
            </div>
            <div className="ml-2 text-sm">
              <div className="font-medium">SoldatRyan</div>
              <div className="text-xs text-neutral-400">Homme du rang 188th</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;