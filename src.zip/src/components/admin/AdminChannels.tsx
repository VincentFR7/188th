import React, { useState, useEffect } from 'react';
import { MessageSquare, PlusCircle, Edit, Trash2, LockIcon, UnlockIcon, CheckCircle, XCircle } from 'lucide-react';
import { getCategories, createChannel, deleteChannel, updateChannel } from '../../services/forumService';
import { Category, Channel } from '../../types/Forum';

const AdminChannels: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [editingChannel, setEditingChannel] = useState<string | null>(null);
  
  const [newChannel, setNewChannel] = useState({
    name: '',
    description: '',
    categoryId: '',
    icon: 'MessageSquare',
    restricted: false
  });
  
  const fetchCategories = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await getCategories();
      setCategories(data);
    } catch (err) {
      setError('Erreur lors du chargement des catégories');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    fetchCategories();
  }, []);
  
  const handleCreateChannel = async () => {
    if (!newChannel.name || !newChannel.description || !newChannel.categoryId) {
      setError('Veuillez remplir tous les champs obligatoires');
      return;
    }
    
    try {
      const created = await createChannel(newChannel.categoryId, {
        name: newChannel.name,
        description: newChannel.description,
        icon: newChannel.icon,
        restricted: newChannel.restricted
      });
      
      if (created) {
        // Rafraîchir la liste des catégories
        fetchCategories();
        // Réinitialiser le formulaire
        setNewChannel({
          name: '',
          description: '',
          categoryId: '',
          icon: 'MessageSquare',
          restricted: false
        });
        setIsCreating(false);
      }
    } catch (err) {
      setError('Erreur lors de la création du salon');
      console.error(err);
    }
  };
  
  const handleDeleteChannel = async (channelId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce salon ? Cette action est irréversible.')) {
      try {
        const success = await deleteChannel(channelId);
        
        if (success) {
          // Rafraîchir la liste des catégories
          fetchCategories();
        }
      } catch (err) {
        setError('Erreur lors de la suppression du salon');
        console.error(err);
      }
    }
  };
  
  const handleEditChannel = (channel: Channel) => {
    setEditingChannel(channel.id);
    setNewChannel({
      name: channel.name,
      description: channel.description,
      categoryId: channel.category,
      icon: channel.icon,
      restricted: channel.restricted || false
    });
  };
  
  const handleUpdateChannel = async (channelId: string) => {
    try {
      const updated = await updateChannel(channelId, {
        name: newChannel.name,
        description: newChannel.description,
        icon: newChannel.icon,
        restricted: newChannel.restricted
      });
      
      if (updated) {
        // Rafraîchir la liste des catégories
        fetchCategories();
        // Réinitialiser le formulaire
        setNewChannel({
          name: '',
          description: '',
          categoryId: '',
          icon: 'MessageSquare',
          restricted: false
        });
        setEditingChannel(null);
      }
    } catch (err) {
      setError('Erreur lors de la mise à jour du salon');
      console.error(err);
    }
  };
  
  const handleCancelEdit = () => {
    setEditingChannel(null);
    setNewChannel({
      name: '',
      description: '',
      categoryId: '',
      icon: 'MessageSquare',
      restricted: false
    });
  };
  
  const iconOptions = [
    { value: 'MessageSquare', label: 'Message' },
    { value: 'Users', label: 'Utilisateurs' },
    { value: 'Shield', label: 'Bouclier' },
    { value: 'Flag', label: 'Drapeau' },
    { value: 'Star', label: 'Étoile' },
    { value: 'Award', label: 'Médaille' }
  ];
  
  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Gestion des Salons</h2>
        <button 
          onClick={() => setIsCreating(!isCreating)}
          className="flex items-center bg-amber-600 hover:bg-amber-700 text-white px-3 py-2 rounded text-sm transition-colors"
        >
          {isCreating ? (
            <>
              <XCircle size={16} className="mr-2" />
              <span>Annuler</span>
            </>
          ) : (
            <>
              <PlusCircle size={16} className="mr-2" />
              <span>Nouveau salon</span>
            </>
          )}
        </button>
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-900/50 border border-red-700 rounded text-red-200 text-sm">
          {error}
        </div>
      )}
      
      {isCreating && (
        <div className="mb-6 bg-neutral-800/50 border border-neutral-700 rounded-lg p-4">
          <h3 className="text-lg font-medium mb-3">Créer un nouveau salon</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-1">Nom</label>
              <input
                type="text"
                value={newChannel.name}
                onChange={(e) => setNewChannel({ ...newChannel, name: e.target.value })}
                className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="Nom du salon"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-1">Catégorie</label>
              <select
                value={newChannel.categoryId}
                onChange={(e) => setNewChannel({ ...newChannel, categoryId: e.target.value })}
                className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
              >
                <option value="">Sélectionner une catégorie</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-1">Icône</label>
              <select
                value={newChannel.icon}
                onChange={(e) => setNewChannel({ ...newChannel, icon: e.target.value })}
                className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
              >
                {iconOptions.map(icon => (
                  <option key={icon.value} value={icon.value}>{icon.label}</option>
                ))}
              </select>
            </div>
            
            <div className="flex items-center">
              <label className="inline-flex items-center cursor-pointer mt-4">
                <input
                  type="checkbox"
                  checked={newChannel.restricted}
                  onChange={(e) => setNewChannel({ ...newChannel, restricted: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="relative w-11 h-6 bg-neutral-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-amber-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                <span className="ml-3 text-sm font-medium text-neutral-300">Accès restreint</span>
              </label>
            </div>
          </div>
          
          <div className="mt-4">
            <label className="block text-sm font-medium text-neutral-300 mb-1">Description</label>
            <textarea
              value={newChannel.description}
              onChange={(e) => setNewChannel({ ...newChannel, description: e.target.value })}
              className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
              placeholder="Description du salon"
              rows={2}
            ></textarea>
          </div>
          
          <div className="mt-4 flex justify-end">
            <button
              onClick={handleCreateChannel}
              className="flex items-center bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded transition-colors"
            >
              <PlusCircle size={16} className="mr-2" />
              <span>Créer le salon</span>
            </button>
          </div>
        </div>
      )}
      
      {loading ? (
        <div className="text-center py-6">
          <div className="inline-block w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-neutral-400">Chargement des salons...</p>
        </div>
      ) : (
        <div className="space-y-6">
          {categories.map(category => (
            <div key={category.id} className="bg-neutral-800/20 border border-neutral-700 rounded-lg overflow-hidden">
              <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-700">
                <h3 className="font-bold">{category.name}</h3>
              </div>
              
              <div className="divide-y divide-neutral-700/50">
                {category.channels.map(channel => (
                  <div key={channel.id} className="p-4 hover:bg-neutral-800/30 transition-colors">
                    {editingChannel === channel.id ? (
                      <div className="space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <input
                              type="text"
                              value={newChannel.name}
                              onChange={(e) => setNewChannel({ ...newChannel, name: e.target.value })}
                              className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
                              placeholder="Nom du salon"
                            />
                          </div>
                          
                          <div>
                            <select
                              value={newChannel.icon}
                              onChange={(e) => setNewChannel({ ...newChannel, icon: e.target.value })}
                              className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
                            >
                              {iconOptions.map(icon => (
                                <option key={icon.value} value={icon.value}>{icon.label}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                        
                        <div>
                          <textarea
                            value={newChannel.description}
                            onChange={(e) => setNewChannel({ ...newChannel, description: e.target.value })}
                            className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
                            placeholder="Description du salon"
                            rows={2}
                          ></textarea>
                        </div>
                        
                        <div className="flex items-center">
                          <label className="inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newChannel.restricted}
                              onChange={(e) => setNewChannel({ ...newChannel, restricted: e.target.checked })}
                              className="sr-only peer"
                            />
                            <div className="relative w-11 h-6 bg-neutral-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-amber-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                            <span className="ml-3 text-sm font-medium text-neutral-300">Accès restreint</span>
                          </label>
                        </div>
                        
                        <div className="flex space-x-2 justify-end">
                          <button 
                            onClick={() => handleUpdateChannel(channel.id)}
                            className="p-1.5 bg-green-700/20 text-green-500 rounded hover:bg-green-700/40 transition-colors flex items-center"
                          >
                            <CheckCircle size={16} className="mr-1" />
                            <span className="text-xs">Enregistrer</span>
                          </button>
                          <button 
                            onClick={handleCancelEdit}
                            className="p-1.5 bg-red-700/20 text-red-500 rounded hover:bg-red-700/40 transition-colors flex items-center"
                          >
                            <XCircle size={16} className="mr-1" />
                            <span className="text-xs">Annuler</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start justify-between">
                        <div className="flex items-start">
                          <div className="p-2 bg-neutral-700 rounded-lg mr-3">
                            <MessageSquare size={16} />
                          </div>
                          
                          <div>
                            <div className="flex items-center">
                              <h4 className="font-medium text-white">{channel.name}</h4>
                              {channel.restricted && (
                                <span className="ml-2 text-xs bg-amber-600/20 text-amber-500 px-1.5 py-0.5 rounded flex items-center">
                                  <LockIcon size={10} className="mr-1" />
                                  Restreint
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-neutral-400 mt-0.5">{channel.description}</p>
                          </div>
                        </div>
                        
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => handleEditChannel(channel)}
                            className="p-1 bg-neutral-700/30 text-neutral-400 rounded hover:bg-neutral-700/60 hover:text-white transition-colors"
                            title="Modifier"
                          >
                            <Edit size={16} />
                          </button>
                          <button 
                            onClick={() => handleDeleteChannel(channel.id)}
                            className="p-1 bg-red-900/20 text-red-400 rounded hover:bg-red-900/40 hover:text-red-300 transition-colors"
                            title="Supprimer"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                
                {category.channels.length === 0 && (
                  <div className="p-4 text-center text-neutral-500 italic">
                    Aucun salon dans cette catégorie
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminChannels;