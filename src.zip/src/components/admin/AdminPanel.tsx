import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import { Users, MessageSquare, Settings, PlusCircle, Trash2, Edit, Shield } from 'lucide-react';
import AdminUsers from './AdminUsers';
import AdminChannels from './AdminChannels';
import AdminCategories from './AdminCategories';

const AdminPanel: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<string>('users');
  
  useEffect(() => {
    // Rediriger vers le premier onglet par défaut
    navigate('/admin/users');
  }, []);
  
  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      <div className="bg-neutral-800/30 border border-neutral-700 rounded-lg p-4 mb-6">
        <div className="flex items-center space-x-2 mb-2">
          <Shield className="h-5 w-5 text-amber-500" />
          <h1 className="text-xl font-bold">Panneau d'Administration</h1>
        </div>
        <p className="text-neutral-300">
          Gérez les utilisateurs, les catégories et les salons du forum du 188<sup>th</sup> Regiment.
        </p>
      </div>
      
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar de navigation */}
        <div className="w-full md:w-64 bg-neutral-800/20 border border-neutral-700 rounded-lg p-4">
          <h2 className="font-semibold text-lg mb-4 text-amber-500">Administration</h2>
          
          <nav className="space-y-1">
            <Link 
              to="/admin/users" 
              className={`flex items-center p-2 rounded-md transition-colors ${activeTab === 'users' ? 'bg-amber-600/20 text-amber-500' : 'hover:bg-neutral-700 text-neutral-300'}`}
              onClick={() => setActiveTab('users')}
            >
              <Users size={18} className="mr-2" />
              <span>Utilisateurs</span>
            </Link>
            
            <Link 
              to="/admin/channels" 
              className={`flex items-center p-2 rounded-md transition-colors ${activeTab === 'channels' ? 'bg-amber-600/20 text-amber-500' : 'hover:bg-neutral-700 text-neutral-300'}`}
              onClick={() => setActiveTab('channels')}
            >
              <MessageSquare size={18} className="mr-2" />
              <span>Salons</span>
            </Link>
            
            <Link 
              to="/admin/categories" 
              className={`flex items-center p-2 rounded-md transition-colors ${activeTab === 'categories' ? 'bg-amber-600/20 text-amber-500' : 'hover:bg-neutral-700 text-neutral-300'}`}
              onClick={() => setActiveTab('categories')}
            >
              <Settings size={18} className="mr-2" />
              <span>Catégories</span>
            </Link>
          </nav>
          
          <div className="mt-8 pt-4 border-t border-neutral-700">
            <p className="text-neutral-500 text-sm">
              Connecté en tant qu'administrateur
            </p>
          </div>
        </div>
        
        {/* Contenu principal */}
        <div className="flex-1 bg-neutral-800/20 border border-neutral-700 rounded-lg overflow-hidden">
          <Routes>
            <Route path="users" element={<AdminUsers />} />
            <Route path="channels" element={<AdminChannels />} />
            <Route path="categories" element={<AdminCategories />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;