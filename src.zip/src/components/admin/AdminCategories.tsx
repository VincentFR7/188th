import React, { useState, useEffect } from 'react';
import { FolderIcon, PlusCircle, Edit, Trash2, LockIcon, CheckCircle, XCircle } from 'lucide-react';
import { getCategories, createCategory, deleteCategory } from '../../services/forumService';
import { Category } from '../../types/Forum';

const AdminCategories: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  
  const [newCategory, setNewCategory] = useState({
    name: '',
    description: '',
    restricted: false
  });
  
  const fetchCategories = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await getCategories();
      setCategories(data);
    } catch (err) {
      setError('Erreur lors du chargement des catégories');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    fetchCategories();
  }, []);
  
  const handleCreateCategory = async () => {
    if (!newCategory.name || !newCategory.description) {
      setError('Veuillez remplir tous les champs obligatoires');
      return;
    }
    
    try {
      await createCategory({
        name: newCategory.name,
        description: newCategory.description,
        restricted: newCategory.restricted
      });
      
      // Rafraîchir la liste des catégories
      fetchCategories();
      // Réinitialiser le formulaire
      setNewCategory({
        name: '',
        description: '',
        restricted: false
      });
      setIsCreating(false);
    } catch (err) {
      setError('Erreur lors de la création de la catégorie');
      console.error(err);
    }
  };
  
  const handleDeleteCategory = async (categoryId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ? Tous les salons associés seront également supprimés. Cette action est irréversible.')) {
      try {
        const success = await deleteCategory(categoryId);
        
        if (success) {
          // Rafraîchir la liste des catégories
          fetchCategories();
        }
      } catch (err) {
        setError('Erreur lors de la suppression de la catégorie');
        console.error(err);
      }
    }
  };
  
  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Gestion des Catégories</h2>
        <button 
          onClick={() => setIsCreating(!isCreating)}
          className="flex items-center bg-amber-600 hover:bg-amber-700 text-white px-3 py-2 rounded text-sm transition-colors"
        >
          {isCreating ? (
            <>
              <XCircle size={16} className="mr-2" />
              <span>Annuler</span>
            </>
          ) : (
            <>
              <PlusCircle size={16} className="mr-2" />
              <span>Nouvelle catégorie</span>
            </>
          )}
        </button>
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-900/50 border border-red-700 rounded text-red-200 text-sm">
          {error}
        </div>
      )}
      
      {isCreating && (
        <div className="mb-6 bg-neutral-800/50 border border-neutral-700 rounded-lg p-4">
          <h3 className="text-lg font-medium mb-3">Créer une nouvelle catégorie</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-1">Nom</label>
              <input
                type="text"
                value={newCategory.name}
                onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="Nom de la catégorie"
              />
            </div>
            
            <div className="flex items-center">
              <label className="inline-flex items-center cursor-pointer mt-4">
                <input
                  type="checkbox"
                  checked={newCategory.restricted}
                  onChange={(e) => setNewCategory({ ...newCategory, restricted: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="relative w-11 h-6 bg-neutral-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-amber-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                <span className="ml-3 text-sm font-medium text-neutral-300">Accès restreint</span>
              </label>
            </div>
          </div>
          
          <div className="mt-4">
            <label className="block text-sm font-medium text-neutral-300 mb-1">Description</label>
            <textarea
              value={newCategory.description}
              onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
              className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-white focus:ring-amber-500 focus:border-amber-500 outline-none"
              placeholder="Description de la catégorie"
              rows={2}
            ></textarea>
          </div>
          
          <div className="mt-4 flex justify-end">
            <button
              onClick={handleCreateCategory}
              className="flex items-center bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded transition-colors"
            >
              <PlusCircle size={16} className="mr-2" />
              <span>Créer la catégorie</span>
            </button>
          </div>
        </div>
      )}
      
      {loading ? (
        <div className="text-center py-6">
          <div className="inline-block w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-neutral-400">Chargement des catégories...</p>
        </div>
      ) : (
        <div className="space-y-4">
          {categories.map(category => (
            <div key={category.id} className="bg-neutral-800/20 border border-neutral-700 rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start">
                  <div className="p-2 bg-neutral-700 rounded-lg mr-3">
                    <FolderIcon size={16} />
                  </div>
                  
                  <div>
                    <div className="flex items-center">
                      <h3 className="font-medium text-white">{category.name}</h3>
                      {category.restricted && (
                        <span className="ml-2 text-xs bg-amber-600/20 text-amber-500 px-1.5 py-0.5 rounded flex items-center">
                          <LockIcon size={10} className="mr-1" />
                          Restreint
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-neutral-400 mt-0.5">{category.description}</p>
                    <div className="text-xs text-neutral-500 mt-1">
                      {category.channels.length} salons
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleDeleteCategory(category.id)}
                    className="p-1 bg-red-900/20 text-red-400 rounded hover:bg-red-900/40 hover:text-red-300 transition-colors"
                    title="Supprimer"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
          
          {categories.length === 0 && (
            <div className="text-center py-8 text-neutral-500">
              <FolderIcon size={32} className="mx-auto mb-2 opacity-50" />
              <p>Aucune catégorie disponible</p>
              <p className="text-sm mt-1">Créez une nouvelle catégorie pour commencer</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AdminCategories;