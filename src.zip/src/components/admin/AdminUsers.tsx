import React, { useState, useEffect } from 'react';
import { User as UserIcon, Shield, Award, CheckCircle, XCircle } from 'lucide-react';
import { getAllUsers, updateUserRole } from '../../services/authService';
import { User, Role, Rank } from '../../types/User';

const AdminUsers: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<Role>('user');
  const [selectedRank, setSelectedRank] = useState<Rank>('Homme du rang 188th');
  
  const fetchUsers = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await getAllUsers();
      setUsers(data);
    } catch (err) {
      setError('Erreur lors du chargement des utilisateurs');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    fetchUsers();
  }, []);
  
  const handleEditUser = (user: User) => {
    setEditingUser(user.id);
    setSelectedRole(user.role);
    setSelectedRank(user.rank);
  };
  
  const handleCancelEdit = () => {
    setEditingUser(null);
  };
  
  const handleSaveUser = async (userId: string) => {
    try {
      await updateUserRole(userId, selectedRole, selectedRank);
      
      // Mettre à jour la liste des utilisateurs
      setUsers(prev => prev.map(user => {
        if (user.id === userId) {
          return {
            ...user,
            role: selectedRole,
            rank: selectedRank,
            isAdmin: selectedRole === 'admin',
            isModerator: selectedRole === 'moderator' || selectedRole === 'admin'
          };
        }
        return user;
      }));
      
      setEditingUser(null);
    } catch (err) {
      setError('Erreur lors de la mise à jour de l\'utilisateur');
      console.error(err);
    }
  };
  
  const getRoleDisplay = (role: Role) => {
    switch (role) {
      case 'admin':
        return <span className="text-xs bg-red-900/30 text-red-400 px-2 py-0.5 rounded">Administrateur</span>;
      case 'moderator':
        return <span className="text-xs bg-amber-900/30 text-amber-400 px-2 py-0.5 rounded">Modérateur</span>;
      default:
        return <span className="text-xs bg-neutral-800 text-neutral-400 px-2 py-0.5 rounded">Utilisateur</span>;
    }
  };
  
  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold mb-4">Gestion des Utilisateurs</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-900/50 border border-red-700 rounded text-red-200 text-sm">
          {error}
        </div>
      )}
      
      {loading ? (
        <div className="text-center py-6">
          <div className="inline-block w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-neutral-400">Chargement des utilisateurs...</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-neutral-800/50 border-b border-neutral-700">
              <tr>
                <th className="px-4 py-3 text-sm font-medium">Utilisateur</th>
                <th className="px-4 py-3 text-sm font-medium">Email</th>
                <th className="px-4 py-3 text-sm font-medium">Rôle</th>
                <th className="px-4 py-3 text-sm font-medium">Grade</th>
                <th className="px-4 py-3 text-sm font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-700/50">
              {users.map(user => (
                <tr key={user.id} className="hover:bg-neutral-800/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-neutral-700 flex items-center justify-center overflow-hidden mr-2">
                        {user.avatar ? (
                          <img src={user.avatar} alt={user.username} className="w-full h-full object-cover" />
                        ) : (
                          <UserIcon size={16} className="text-neutral-300" />
                        )}
                      </div>
                      <span className="font-medium">{user.username}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-neutral-400">{user.email}</td>
                  <td className="px-4 py-3">
                    {editingUser === user.id ? (
                      <select 
                        value={selectedRole} 
                        onChange={(e) => setSelectedRole(e.target.value as Role)}
                        className="bg-neutral-700 border border-neutral-600 text-white rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                      >
                        <option value="user">Utilisateur</option>
                        <option value="moderator">Modérateur</option>
                        <option value="admin">Administrateur</option>
                      </select>
                    ) : (
                      getRoleDisplay(user.role)
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {editingUser === user.id ? (
                      <select 
                        value={selectedRank} 
                        onChange={(e) => setSelectedRank(e.target.value as Rank)}
                        className="bg-neutral-700 border border-neutral-600 text-white rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                      >
                        <option value="Homme du rang 188th">Homme du rang 188th</option>
                        <option value="Sous-Officier 188th">Sous-Officier 188th</option>
                        <option value="Officier 188th">Officier 188th</option>
                      </select>
                    ) : (
                      <span className="text-amber-500">{user.rank}</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {editingUser === user.id ? (
                      <div className="flex space-x-2">
                        <button 
                          onClick={() => handleSaveUser(user.id)}
                          className="p-1 bg-green-700/20 text-green-500 rounded hover:bg-green-700/40 transition-colors"
                          title="Enregistrer"
                        >
                          <CheckCircle size={16} />
                        </button>
                        <button 
                          onClick={handleCancelEdit}
                          className="p-1 bg-red-700/20 text-red-500 rounded hover:bg-red-700/40 transition-colors"
                          title="Annuler"
                        >
                          <XCircle size={16} />
                        </button>
                      </div>
                    ) : (
                      <button 
                        onClick={() => handleEditUser(user)}
                        className="p-1 bg-neutral-700/30 text-neutral-400 rounded hover:bg-neutral-700/60 hover:text-white transition-colors"
                        title="Modifier"
                      >
                        <Shield size={16} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminUsers;