import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, User, Lock, Mail, FileText } from 'lucide-react';

const Register: React.FC = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }
    
    setLoading(true);
    setError('');
    
    try {
      // Simuler un délai d'inscription
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulation d'une redirection après inscription réussie
      navigate('/login');
    } catch (err) {
      setError('Une erreur est survenue lors de l\'inscription. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-register-pattern bg-cover bg-center">
      <div className="w-full max-w-md px-8 py-10 bg-neutral-800/80 backdrop-blur-sm text-white rounded-lg shadow-xl border border-neutral-700">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-3 bg-neutral-900 rounded-full mb-4">
            <Shield className="h-8 w-8 text-amber-500" />
          </div>
          <h1 className="text-2xl font-bold">188<sup>th</sup> Regiment</h1>
          <p className="text-neutral-400 mt-1">Inscription au forum</p>
        </div>
        
        {error && (
          <div className="mb-4 p-3 bg-red-900/50 border border-red-700 rounded text-red-200 text-sm">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-neutral-300 mb-1.5">
              Nom d'utilisateur
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className="h-4 w-4 text-neutral-500" />
              </div>
              <input
                id="username"
                name="username"
                type="text"
                required
                value={formData.username}
                onChange={handleChange}
                className="bg-neutral-900 border border-neutral-700 text-white block w-full pl-10 pr-3 py-2.5 rounded focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="Choisissez un nom d'utilisateur"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-neutral-300 mb-1.5">
              Adresse email
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-4 w-4 text-neutral-500" />
              </div>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleChange}
                className="bg-neutral-900 border border-neutral-700 text-white block w-full pl-10 pr-3 py-2.5 rounded focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="votre@email.com"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-neutral-300 mb-1.5">
              Mot de passe
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-4 w-4 text-neutral-500" />
              </div>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={formData.password}
                onChange={handleChange}
                className="bg-neutral-900 border border-neutral-700 text-white block w-full pl-10 pr-3 py-2.5 rounded focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="Créez un mot de passe sécurisé"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-neutral-300 mb-1.5">
              Confirmez le mot de passe
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <FileText className="h-4 w-4 text-neutral-500" />
              </div>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                required
                value={formData.confirmPassword}
                onChange={handleChange}
                className="bg-neutral-900 border border-neutral-700 text-white block w-full pl-10 pr-3 py-2.5 rounded focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="Répétez votre mot de passe"
              />
            </div>
          </div>
          
          <div className="mt-6">
            <button
              type="submit"
              disabled={loading}
              className={`w-full flex justify-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 transition-colors ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {loading ? 'Inscription en cours...' : 'S\'inscrire'}
            </button>
          </div>
        </form>
        
        <div className="mt-6 text-center text-sm">
          <p className="text-neutral-400">
            Déjà membre?{' '}
            <Link to="/login" className="font-medium text-amber-500 hover:text-amber-400">
              Se connecter
            </Link>
          </p>
        </div>
        
        <div className="mt-4 pt-4 border-t border-neutral-700">
          <p className="text-xs text-neutral-400 text-center">
            En vous inscrivant, vous acceptez les conditions d'utilisation et la politique de confidentialité du 188<sup>th</sup> Regiment.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;