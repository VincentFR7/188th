import React, { useState, useContext } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Shield, User, Lock } from 'lucide-react';
import UserContext from '../../contexts/UserContext';
import { loginUser } from '../../services/authService';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login } = useContext(UserContext);
  const navigate = useNavigate();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      // Simuler un délai de connexion
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const user = await loginUser(username, password);
      if (user) {
        login(user);
        navigate('/');
      } else {
        setError('Identifiants incorrects. Veuillez réessayer.');
      }
    } catch (err) {
      setError('Une erreur est survenue. Veuillez réessayer plus tard.');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-login-pattern bg-cover bg-center">
      <div className="w-full max-w-md px-8 py-10 bg-neutral-800/80 backdrop-blur-sm text-white rounded-lg shadow-xl border border-neutral-700">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-3 bg-neutral-900 rounded-full mb-4">
            <Shield className="h-8 w-8 text-amber-500" />
          </div>
          <h1 className="text-2xl font-bold">188<sup>th</sup> Regiment</h1>
          <p className="text-neutral-400 mt-1">Portail d'authentification</p>
        </div>
        
        {error && (
          <div className="mb-4 p-3 bg-red-900/50 border border-red-700 rounded text-red-200 text-sm">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-neutral-300 mb-1.5">
              Nom d'utilisateur
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className="h-4 w-4 text-neutral-500" />
              </div>
              <input
                id="username"
                type="text"
                autoComplete="username"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-neutral-900 border border-neutral-700 text-white block w-full pl-10 pr-3 py-2.5 rounded focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="Votre identifiant"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-neutral-300 mb-1.5">
              Mot de passe
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-4 w-4 text-neutral-500" />
              </div>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-neutral-900 border border-neutral-700 text-white block w-full pl-10 pr-3 py-2.5 rounded focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="Votre mot de passe"
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                className="h-4 w-4 accent-amber-500 bg-neutral-900 border-neutral-700 rounded focus:ring-amber-500"
              />
              <label htmlFor="remember-me" className="ml-2 block text-sm text-neutral-300">
                Se souvenir de moi
              </label>
            </div>
            
            <div className="text-sm">
              <a href="#" className="font-medium text-amber-500 hover:text-amber-400">
                Mot de passe oublié?
              </a>
            </div>
          </div>
          
          <div>
            <button
              type="submit"
              disabled={loading}
              className={`w-full flex justify-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 transition-colors ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {loading ? 'Connexion en cours...' : 'Se connecter'}
            </button>
          </div>
        </form>
        
        <div className="mt-6 text-center text-sm">
          <p className="text-neutral-400">
            Pas encore de compte?{' '}
            <Link to="/register" className="font-medium text-amber-500 hover:text-amber-400">
              S'inscrire
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;