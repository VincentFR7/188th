import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import UserContext from '../../contexts/UserContext';
import { Role } from '../../types/User';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: Role;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, requiredRole = 'user' }) => {
  const { currentUser, isAuthenticated } = useContext(UserContext);
  
  // Vérifier si l'utilisateur est authentifié
  if (!isAuthenticated || !currentUser) {
    return <Navigate to="/login" replace />;
  }
  
  // Vérifier si l'utilisateur a le rôle requis
  if (requiredRole === 'admin' && currentUser.role !== 'admin') {
    return <Navigate to="/" replace />;
  }
  
  if (requiredRole === 'moderator' && 
      currentUser.role !== 'moderator' && 
      currentUser.role !== 'admin') {
    return <Navigate to="/" replace />;
  }
  
  // L'utilisateur est authentifié et a les permissions requises
  return <>{children}</>;
};

export default ProtectedRoute;