import { User, Role, Rank } from '../types/User';

// Données utilisateurs simulées (à remplacer par une vraie API)
const mockUsers: User[] = [
  {
    id: '1',
    username: 'CommanderPrice',
    email: 'commander@188regiment.fr',
    password: 'password123',
    role: 'admin',
    rank: 'Officier 188th',
    isAdmin: true,
    createdAt: '2024-01-01'
  },
  {
    id: '2',
    username: 'MajorTom',
    email: 'major@188regiment.fr',
    password: 'password123',
    role: 'moderator',
    rank: 'Sous-Officier 188th',
    isModerator: true,
    createdAt: '2024-01-10'
  },
  {
    id: '3',
    username: 'SoldatRyan',
    email: 'ryan@188regiment.fr',
    password: 'password123',
    role: 'user',
    rank: 'Homme du rang 188th',
    createdAt: '2024-02-15'
  }
];

// Simuler un délai réseau
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const loginUser = async (username: string, password: string): Promise<User | null> => {
  // Simuler un appel API
  await delay(800);
  
  const user = mockUsers.find(
    u => u.username.toLowerCase() === username.toLowerCase() && u.password === password
  );
  
  if (user) {
    // Ne pas renvoyer le mot de passe au client
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }
  
  return null;
};

export const registerUser = async (
  username: string, 
  email: string, 
  password: string
): Promise<User | null> => {
  // Simuler un appel API
  await delay(1200);
  
  // Vérifier si l'utilisateur existe déjà
  const existingUser = mockUsers.find(
    u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === email.toLowerCase()
  );
  
  if (existingUser) {
    return null;
  }
  
  // Créer un nouvel utilisateur
  const newUser: User = {
    id: (mockUsers.length + 1).toString(),
    username,
    email,
    password,
    role: 'user',
    rank: 'Homme du rang 188th',
    createdAt: new Date().toISOString(),
  };
  
  mockUsers.push(newUser);
  
  // Ne pas renvoyer le mot de passe au client
  const { password: _, ...userWithoutPassword } = newUser;
  return userWithoutPassword;
};

export const updateUserRole = async (userId: string, newRole: Role, newRank: Rank): Promise<boolean> => {
  // Simuler un appel API
  await delay(500);
  
  const userIndex = mockUsers.findIndex(u => u.id === userId);
  
  if (userIndex === -1) {
    return false;
  }
  
  mockUsers[userIndex].role = newRole;
  mockUsers[userIndex].rank = newRank;
  mockUsers[userIndex].isAdmin = newRole === 'admin';
  mockUsers[userIndex].isModerator = newRole === 'moderator' || newRole === 'admin';
  
  return true;
};

export const getAllUsers = async (): Promise<Omit<User, 'password'>[]> => {
  // Simuler un appel API
  await delay(600);
  
  // Renvoyer les utilisateurs sans leurs mots de passe
  return mockUsers.map(({ password, ...user }) => user);
};