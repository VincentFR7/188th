import { Category, Channel, Post, ForumStats } from '../types/Forum';
import { User } from '../types/User';

// Simuler un délai réseau
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Données de forum simulées
let mockCategories: Category[] = [
  {
    id: 'general',
    name: 'Général',
    description: 'Informations générales et règlement du forum',
    channels: [
      {
        id: 'announcements',
        name: 'Annonces',
        description: 'Informations et annonces importantes concernant le 188th Regiment',
        category: 'general',
        icon: 'Flag',
        posts: [
          {
            id: '1',
            author: {
              id: '1',
              username: 'CommanderPrice',
              email: 'commander@188regiment.fr',
              role: 'admin',
              rank: 'Officier 188th',
              isAdmin: true,
              createdAt: '2024-01-01'
            },
            content: `Soldats du 188th Regiment,

Je vous informe de notre prochaine opération majeure qui aura lieu le 15 juin. Tous les membres sont attendus pour un briefing préliminaire le 10 juin à 20h sur notre serveur Discord.

L'opération "Marteau de Thor" sera notre plus grande mission à ce jour. Préparez votre équipement et révisez vos procédures opérationnelles standards.

Pour la gloire du 188th!`,
            createdAt: '2025-05-28T10:32:00Z',
            pinned: true
          }
        ]
      },
      {
        id: 'welcome',
        name: 'Bienvenue',
        description: 'Présentez-vous aux autres membres du regiment',
        category: 'general',
        icon: 'Users',
        posts: []
      },
      {
        id: 'rules',
        name: 'Règlement',
        description: 'Règles du forum et du regiment',
        category: 'general',
        icon: 'Shield',
        posts: []
      }
    ]
  },
  {
    id: 'regiment',
    name: '188th Regiment',
    description: 'Tout ce qui concerne les opérations, la stratégie et les entraînements',
    restricted: true,
    channels: [
      {
        id: 'missions',
        name: 'Missions',
        description: 'Discussions sur les missions passées et à venir',
        category: 'regiment',
        icon: 'Star',
        restricted: true,
        posts: [
          {
            id: '2',
            author: {
              id: '2',
              username: 'MajorTom',
              email: 'major@188regiment.fr',
              role: 'moderator',
              rank: 'Sous-Officier 188th',
              isModerator: true,
              createdAt: '2024-01-10'
            },
            content: `Débriefing de la mission "Aigle Noir"

Excellente performance de toutes les escouades lors de cette opération. Points à améliorer:
- Coordination radio entre les équipes Alpha et Bravo
- Temps de réaction lors de l'embuscade du secteur Est
- Utilisation des fumigènes pour couvrir les évacuations

Mentions spéciales:
- SoldatRyan pour la neutralisation du nid de mitrailleuses
- Équipe Charlie pour la sécurisation de l'objectif secondaire en temps record`,
            createdAt: '2025-05-25T18:45:00Z'
          }
        ]
      },
      {
        id: 'training',
        name: 'Entraînement',
        description: 'Planification et retour sur les sessions d\'entraînement',
        category: 'regiment',
        icon: 'Award',
        restricted: true,
        posts: []
      },
      {
        id: 'operations',
        name: 'Opérations',
        description: 'Coordination des opérations tactiques',
        category: 'regiment',
        icon: 'MessageSquare',
        restricted: true,
        posts: []
      }
    ]
  }
];

// Stats simulées
const mockStats: ForumStats = {
  totalMembers: 124,
  totalPosts: 2357,
  onlineMembers: 12,
  lastMember: {
    id: '3',
    username: 'SoldatRyan',
    email: 'ryan@188regiment.fr',
    role: 'user',
    rank: 'Homme du rang 188th',
    createdAt: '2024-02-15'
  }
};

// Liste des membres en ligne simulée
const mockOnlineMembers: User[] = [
  {
    id: '1',
    username: 'CommanderPrice',
    email: 'commander@188regiment.fr',
    role: 'admin',
    rank: 'Officier 188th',
    isAdmin: true,
    createdAt: '2024-01-01'
  },
  {
    id: '2',
    username: 'MajorTom',
    email: 'major@188regiment.fr',
    role: 'moderator',
    rank: 'Sous-Officier 188th',
    isModerator: true,
    createdAt: '2024-01-10'
  },
  {
    id: '3',
    username: 'SoldatRyan',
    email: 'ryan@188regiment.fr',
    role: 'user',
    rank: 'Homme du rang 188th',
    createdAt: '2024-02-15'
  }
];

// Fonctions d'accès aux données

export const getCategories = async (): Promise<Category[]> => {
  await delay(500);
  return mockCategories;
};

export const getChannel = async (channelId: string): Promise<Channel | null> => {
  await delay(300);
  
  for (const category of mockCategories) {
    const channel = category.channels.find(c => c.id === channelId);
    if (channel) return channel;
  }
  
  return null;
};

export const getForumStats = async (): Promise<ForumStats> => {
  await delay(200);
  return mockStats;
};

export const getOnlineMembers = async (): Promise<User[]> => {
  await delay(200);
  return mockOnlineMembers;
};

export const addPost = async (channelId: string, post: Omit<Post, 'id' | 'createdAt'>): Promise<Post | null> => {
  await delay(800);
  
  for (const category of mockCategories) {
    const channelIndex = category.channels.findIndex(c => c.id === channelId);
    
    if (channelIndex !== -1) {
      const newPost: Post = {
        ...post,
        id: Date.now().toString(),
        createdAt: new Date().toISOString()
      };
      
      mockCategories[mockCategories.indexOf(category)].channels[channelIndex].posts.unshift(newPost);
      return newPost;
    }
  }
  
  return null;
};

// Fonctions d'administration

export const createChannel = async (
  categoryId: string, 
  channel: Omit<Channel, 'id' | 'posts' | 'category'>
): Promise<Channel | null> => {
  await delay(1000);
  
  const categoryIndex = mockCategories.findIndex(c => c.id === categoryId);
  
  if (categoryIndex === -1) {
    return null;
  }
  
  const newChannel: Channel = {
    ...channel,
    id: Date.now().toString(),
    category: categoryId,
    posts: []
  };
  
  mockCategories[categoryIndex].channels.push(newChannel);
  return newChannel;
};

export const createCategory = async (
  category: Omit<Category, 'id' | 'channels'>
): Promise<Category | null> => {
  await delay(1000);
  
  const newCategory: Category = {
    ...category,
    id: Date.now().toString(),
    channels: []
  };
  
  mockCategories.push(newCategory);
  return newCategory;
};

export const deleteChannel = async (channelId: string): Promise<boolean> => {
  await delay(800);
  
  for (const category of mockCategories) {
    const channelIndex = category.channels.findIndex(c => c.id === channelId);
    
    if (channelIndex !== -1) {
      mockCategories[mockCategories.indexOf(category)].channels.splice(channelIndex, 1);
      return true;
    }
  }
  
  return false;
};

export const deleteCategory = async (categoryId: string): Promise<boolean> => {
  await delay(800);
  
  const categoryIndex = mockCategories.findIndex(c => c.id === categoryId);
  
  if (categoryIndex !== -1) {
    mockCategories.splice(categoryIndex, 1);
    return true;
  }
  
  return false;
};

export const updateChannel = async (
  channelId: string, 
  updates: Partial<Omit<Channel, 'id' | 'posts' | 'category'>>
): Promise<Channel | null> => {
  await delay(800);
  
  for (const category of mockCategories) {
    const channelIndex = category.channels.findIndex(c => c.id === channelId);
    
    if (channelIndex !== -1) {
      const updatedChannel = {
        ...mockCategories[mockCategories.indexOf(category)].channels[channelIndex],
        ...updates
      };
      
      mockCategories[mockCategories.indexOf(category)].channels[channelIndex] = updatedChannel;
      return updatedChannel;
    }
  }
  
  return null;
};