export type Role = 'user' | 'moderator' | 'admin';
export type Rank = 'Homme du rang 188th' | 'Sous-Officier 188th' | 'Officier 188th';

export interface User {
  id: string;
  username: string;
  email: string;
  password?: string; // Ne pas transmettre au client
  role: Role;
  rank: Rank;
  avatar?: string | null;
  isAdmin?: boolean;
  isModerator?: boolean;
  createdAt: string;
  lastLogin?: string;
}