import { User } from './User';

export interface Post {
  id: string;
  title?: string;
  content: string;
  author: User;
  createdAt: string;
  updatedAt?: string;
  pinned?: boolean;
  locked?: boolean;
}

export interface Channel {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  posts: Post[];
  restricted?: boolean;
  allowedRoles?: string[];
}

export interface Category {
  id: string;
  name: string;
  description: string;
  channels: Channel[];
  restricted?: boolean;
}

export interface ForumStats {
  totalMembers: number;
  totalPosts: number;
  onlineMembers: number;
  lastMember: User;
}